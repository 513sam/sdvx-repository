
#include <stdio.h>

int main()
{
    int a;
    int b;
    int c;
    int d;
    printf("여행은 몇박인가요?: ");
    scanf("%d",&a);
    printf("\n항공권 가격: ");
    scanf("%d",&b);
    printf("\n호텔 1박 가격: ");
    scanf("%d",&c);
    printf("\n하루에 필요한 용돈: ");
    scanf("%d",&d);
    printf("========================\n총 여행 비용 :  %d \n========================",b+(c+d)*a);

}

